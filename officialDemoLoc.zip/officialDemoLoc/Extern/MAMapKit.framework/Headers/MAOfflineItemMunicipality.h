//
//  MAOfflineItemMunicipality.h
//  MapKit_static
//
//  Created by songjian on 14-4-23.
//  Copyright © 2016 Amap. All rights reserved.
//

#import "MAConfig.h"

#if MA_INCLUDE_OFFLINE

#import "MAOfflineCity.h"

///直辖市
@interface MAOfflineItemMunicipality : MAOfflineCity

@end

#endif
